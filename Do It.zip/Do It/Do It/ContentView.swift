//
//  ContentView.swift
//  Do It
//
//  Created by Alfita Putrimasi Hintarsyah on 27/07/22.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var  timerModel: timerModel
    var body: some View {
        Home()
            .environmentObject(timerModel)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
