//
//  Home.swift
//  Do It
//
//  Created by Alfita Putrimasi Hintarsyah on 27/07/22.
//

import SwiftUI

struct Home: View {
    @EnvironmentObject var timerModel: timerModel
    
    var body: some View {
        VStack{
            Text("Focus Time")
                .bold()
            
            GeometryReader{proxy in
                VStack(spacing: 15){
                    // Timer ring
                    
                    ZStack{
                        
                        Circle()
                            .stroke(Color("buttonPinkish").opacity(0.1),lineWidth: 70)
                            .blur(radius: 4)
                            .padding(-2)
                        
                        Circle()
                            .trim(from: 0, to: timerModel.progress)
                            .stroke(Color("buttonPinkish").opacity(0.1),lineWidth: 70)
                            .blur(radius: 4)
                            .padding(-2)
                    
                        Circle()
                            .stroke(Color("timerRed").opacity(0.7),lineWidth: 10)
                            .blur(radius: 15)
                        
                        Circle()
                            .trim(from: 0, to: timerModel.progress)
                            .stroke(Color("timerRed").opacity(0.7),lineWidth: 15)
                            
                        Circle()
                            .fill(.white)
                        
                        Text(timerModel.timerStringValue)
                            .font(.system(size: 45, weight:  .light))
                            .rotationEffect(.init(degrees: -90))
                            .animation(.none, value: timerModel.progress)
                        
                        
                        // Knob
                        GeometryReader{proxy in let size = proxy.size
                            
                            
                            Circle()
                                .fill(Color("timerRed"))
                                .frame(width: 30, height: 30)
                                .overlay(content : {
                                    Circle()
                                        .fill(.white)
                                        .padding(5)
                                })
                            
                                .frame(width: size.width, height: size.height, alignment: .center)
                            // using X because the view is rotated
                                .offset(x: size.height / 1.95)
                                .rotationEffect(.init(degrees: timerModel.progress))
                            
                            
                            
                        }
                    }
                    .padding(40)
                    .frame(height: proxy.size.width)
                    .rotationEffect(.init(degrees: -90))
                    .animation(.easeInOut, value: timerModel.progress)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

                    
                    Button {
                        if timerModel.isStarted{
                            
                        }else{
                            timerModel.addNewTimer = true
                        }
                    } label: {
                        Image(systemName: !timerModel.isStarted ? "timer" : "pause")
                            .font(.largeTitle.bold())
                            .foregroundColor(.red)
                            .frame(width: 80, height: 80)
                            .background{
                                Circle()
                                    .stroke(.red)
                            }
                    }
                    
                }
                
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            }
        }
        .padding()
        
    }
    
    //New timer bottom sheet
    @ViewBuilder
    func NewTimerView()->some View {
        VStack(spacing: 15){
            
        }
        .padding()
        .frame(width: .infinity)
        .background{
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(.red)
                .ignoresSafeArea()
        }
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(timerModel())
    }
}
