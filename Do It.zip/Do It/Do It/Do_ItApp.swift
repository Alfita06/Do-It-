//
//  Do_ItApp.swift
//  Do It
//
//  Created by Alfita Putrimasi Hintarsyah on 27/07/22.
//

import SwiftUI

@main
struct Do_ItApp: App {
    // Since we're doing background fetching initializing
    @StateObject var timerModel: timerModel = .init()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(timerModel)
        }
    }
}
